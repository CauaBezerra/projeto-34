
const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Body = Matter.Body;

var ball,bolaImg;
var ground,leftside,rightside,base,peDaCesta;
var world, engine;
var radius = 40;

function preload(){
}

function setup() {
	createCanvas(1500, 700);

	engine = Engine.create();
	world = engine.world;



	var balls_options={
		isStatic:false,
		restitution:0.01,
		friction:0,
		frictionAir:0.02,
		density:2
	}
	//ball = Matter.Bodies.circle(100,300,50,balls_options);
	ball = Bodies.circle(260,100,radius/2,balls_options); //criação da bola usando o raio definido la nas variáveis; 
	World.add(world, ball);

		//Create the Bodies Here.
		ground = new Ground(width/2,670,width,20);
		leftside = new Ground(1100,300,20,120);
		rightside = new Ground(1300,300,20,120);
        base = new Ground(1200,350,200,20);
		peDaCesta = new Ground(1300,400,20,550);
	Engine.run(engine);
  
}


function draw() {
  rectMode(CENTER);
  background(0);
 // Engine.update(engine); ja está sendo usado o engine.run

 // push(); //nao é necessário aqui porque só temos uma ellipse;
  //ellipseMode(CENTER); ellipse não se usa com CENTER, e sim com RADIUS(passar de graus para radiano).
  ellipse(ball.position.x,ball.position.y,radius,radius);
  fill("orange");
 // pop();
  ground.display();
  leftside.display();
  rightside.display();
  base.display();
  peDaCesta.display();
 // keyPressed(); //não precisamos chamar essa função porque ela é pré definida, ou seja, ja tem uma funcionalidade própria;
 //quando acontecer de a seta para cima ser apertada, o computador automaticamente encontra a função que verifica isso.
 //chamamos funções quando não são pré definidas;
}

function keyPressed(){
   if(keyCode === UP_ARROW){
    Matter.Body.applyForce(ball,{x:0,y:0},{x:170,y:-260});
   }
}
